
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from pathlib import Path

# =========================================================
# KONFIGURASI HALAMAN
# =========================================================
st.set_page_config(
    page_title="Bike Sharing Dashboard",
    page_icon="🚲",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Palet warna konsisten
BLUE = "#457B9D"
LIGHT_BLUE = "#A8DADC"
ORANGE = "#F4A261"
YELLOW = "#E9C46A"
GREEN = "#2A9D8F"
DARK = "#264653"

SEASON_ORDER = ["Spring", "Summer", "Fall", "Winter"]
DAY_ORDER = ["Working Day", "Weekend/Holiday"]

MONTH_NAMES = {
    1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr",
    5: "Mei", 6: "Jun", 7: "Jul", 8: "Agu",
    9: "Sep", 10: "Okt", 11: "Nov", 12: "Des"
}

st.markdown("""
<style>
    .main-title {
        font-size: 2.15rem;
        font-weight: 750;
        color: #264653;
        margin-bottom: 0.15rem;
    }
    .subtitle {
        color: #64748b;
        font-size: 1rem;
        margin-bottom: 1.3rem;
    }
    div[data-testid="stMetric"] {
        background: #F5F8FA;
        border: 1px solid #E5EAF0;
        padding: 16px 18px;
        border-radius: 12px;
    }
    .section-note {
        color: #64748b;
        font-size: 0.9rem;
    }
</style>
""", unsafe_allow_html=True)


# =========================================================
# MEMUAT DATA
# =========================================================
@st.cache_data
def load_data(uploaded_file=None):

    if uploaded_file is not None:
        df = pd.read_csv(uploaded_file)

    else:
        possible_paths = [
            Path("main_data.csv"),
            Path("dashboard/main_data.csv"),
            Path("data/day.csv"),
            Path("day.csv"),
        ]

        data_path = next(
            (p for p in possible_paths if p.exists()),
            None
        )

        if data_path is None:
            return None

        df = pd.read_csv(data_path)

    # Validasi kolom wajib
    required = {
        "dteday", "season", "yr", "mnth",
        "workingday", "casual", "registered", "cnt"
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            "Kolom berikut tidak ditemukan: "
            + ", ".join(sorted(missing))
        )

    # Penyesuaian tipe data
    df["dteday"] = pd.to_datetime(
        df["dteday"],
        errors="coerce"
    )

    numeric_columns = [
        "season", "yr", "mnth", "workingday",
        "casual", "registered", "cnt"
    ]

    for col in numeric_columns:
        df[col] = pd.to_numeric(
            df[col],
            errors="coerce"
        )

    df = df.dropna(
        subset=[
            "dteday", "season", "yr", "mnth",
            "workingday", "casual", "registered", "cnt"
        ]
    ).copy()

    # Membuat label jika belum tersedia
    season_map = {
        1: "Spring",
        2: "Summer",
        3: "Fall",
        4: "Winter"
    }

    day_map = {
        0: "Weekend/Holiday",
        1: "Working Day"
    }

    if "season_label" not in df.columns:
        df["season_label"] = df["season"].map(season_map)

    if "day_type" not in df.columns:
        df["day_type"] = df["workingday"].map(day_map)

    df["year_label"] = df["yr"].map({
        0: "2011",
        1: "2012"
    })

    df["month_name"] = df["mnth"].map(MONTH_NAMES)

    df = df.dropna(
        subset=["season_label", "day_type"]
    )

    return df


# =========================================================
# SIDEBAR DAN SUMBER DATA
# =========================================================
st.sidebar.title("🚲 Bike Sharing")
st.sidebar.caption("Dashboard Analisis Penyewaan Sepeda")
st.sidebar.markdown("---")

uploaded_file = st.sidebar.file_uploader(
    "Unggah dataset CSV",
    type=["csv"],
    help="Unggah main_data.csv hasil notebook atau day.csv asli."
)

try:
    raw_df = load_data(uploaded_file)

except Exception as error:
    st.error(f"Dataset tidak dapat dibaca: {error}")
    st.stop()

if raw_df is None:

    st.title("🚲 Bike Sharing Dashboard")

    st.info(
        "Dataset belum ditemukan. Unggah file "
        "**main_data.csv** atau **day.csv** "
        "melalui panel di sebelah kiri."
    )

    st.stop()


# =========================================================
# FILTER DATA
# =========================================================
st.sidebar.subheader("Filter Analisis")

year_options = sorted(
    raw_df["year_label"].dropna().unique().tolist()
)

season_options = [
    s for s in SEASON_ORDER
    if s in raw_df["season_label"].unique()
]

day_options = [
    d for d in DAY_ORDER
    if d in raw_df["day_type"].unique()
]

selected_year = st.sidebar.multiselect(
    "Tahun",
    options=year_options,
    default=year_options
)

selected_month = st.sidebar.multiselect(
    "Bulan",
    options=list(range(1, 13)),
    default=list(range(1, 13)),
    format_func=lambda x: MONTH_NAMES[x]
)

selected_season = st.sidebar.multiselect(
    "Musim",
    options=season_options,
    default=season_options
)

selected_day = st.sidebar.multiselect(
    "Jenis Hari",
    options=day_options,
    default=day_options,
    format_func=lambda x: (
        "Hari Kerja"
        if x == "Working Day"
        else "Hari Non-Kerja"
    )
)

filtered_df = raw_df[
    raw_df["year_label"].isin(selected_year)
    & raw_df["mnth"].isin(selected_month)
    & raw_df["season_label"].isin(selected_season)
    & raw_df["day_type"].isin(selected_day)
].copy()

if filtered_df.empty:
    st.warning(
        "Tidak ada data untuk kombinasi filter tersebut. "
        "Silakan ubah filter."
    )
    st.stop()


# =========================================================
# HEADER
# =========================================================
st.markdown(
    '<div class="main-title">🚲 Bike Sharing Dashboard</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">'
    'Analisis pola penyewaan sepeda berdasarkan '
    'musim, waktu, dan segmen pengguna | Periode 2011–2012'
    '</div>',
    unsafe_allow_html=True
)

st.caption(
    f"Menampilkan {len(filtered_df):,} hari pengamatan dari "
    f"{filtered_df['dteday'].min():%d %b %Y} sampai "
    f"{filtered_df['dteday'].max():%d %b %Y}."
)


# =========================================================
# KPI
# =========================================================
total_rentals = int(filtered_df["cnt"].sum())
average_rentals = filtered_df["cnt"].mean()
total_casual = int(filtered_df["casual"].sum())
total_registered = int(filtered_df["registered"].sum())

k1, k2, k3, k4 = st.columns(4)

k1.metric(
    "Total Penyewaan",
    f"{total_rentals:,.0f}"
)

k2.metric(
    "Rata-rata per Hari",
    f"{average_rentals:,.0f}"
)

k3.metric(
    "Pengguna Casual",
    f"{total_casual:,.0f}"
)

k4.metric(
    "Pengguna Registered",
    f"{total_registered:,.0f}"
)

st.markdown("---")


# =========================================================
# GRAFIK 1: MUSIM
# =========================================================
st.subheader(
    "1. Rata-Rata Penyewaan Berdasarkan Musim"
)

season_analysis = (
    filtered_df.groupby(
        "season_label",
        as_index=False
    )
    .agg(
        rata_rata_penyewaan=("cnt", "mean"),
        total_penyewaan=("cnt", "sum"),
        jumlah_hari=("cnt", "count")
    )
)

season_analysis["season_label"] = pd.Categorical(
    season_analysis["season_label"],
    categories=SEASON_ORDER,
    ordered=True
)

season_analysis = season_analysis.sort_values(
    "season_label"
)

fig_season = px.bar(
    season_analysis,
    x="season_label",
    y="rata_rata_penyewaan",
    color="season_label",
    category_orders={
        "season_label": SEASON_ORDER
    },
    color_discrete_map={
        "Spring": LIGHT_BLUE,
        "Summer": BLUE,
        "Fall": ORANGE,
        "Winter": "#8D99AE"
    },
    text_auto=".0f",
    hover_data={
        "total_penyewaan": ":,.0f",
        "jumlah_hari": True,
        "rata_rata_penyewaan": ":,.2f"
    }
)

fig_season.update_layout(
    showlegend=False,
    xaxis_title="Musim",
    yaxis_title="Rata-rata penyewaan per hari",
    margin=dict(l=10, r=10, t=25, b=10)
)

st.plotly_chart(
    fig_season,
    use_container_width=True
)

if not season_analysis.empty:

    highest = season_analysis.loc[
        season_analysis["rata_rata_penyewaan"].idxmax()
    ]

    lowest = season_analysis.loc[
        season_analysis["rata_rata_penyewaan"].idxmin()
    ]

    st.info(
        f"Pada data yang sedang difilter, rata-rata "
        f"penyewaan tertinggi terjadi pada musim "
        f"**{highest['season_label']}** "
        f"({highest['rata_rata_penyewaan']:,.0f} per hari), "
        f"sedangkan terendah pada musim "
        f"**{lowest['season_label']}** "
        f"({lowest['rata_rata_penyewaan']:,.0f} per hari)."
    )

st.markdown("---")


# =========================================================
# GRAFIK 2: KOMPOSISI PENGGUNA
# =========================================================
st.subheader(
    "2. Komposisi Pengguna Casual dan Registered"
)

user_totals = (
    filtered_df.groupby("day_type")[
        ["casual", "registered"]
    ]
    .sum()
    .reindex(DAY_ORDER)
    .dropna(how="all")
)

user_pct = (
    user_totals.div(
        user_totals.sum(axis=1),
        axis=0
    ) * 100
)

user_pct = user_pct.reset_index().melt(
    id_vars="day_type",
    var_name="segmen_pengguna",
    value_name="persentase"
)

user_pct["jenis_hari"] = user_pct["day_type"].map({
    "Working Day": "Hari Kerja",
    "Weekend/Holiday": "Hari Non-Kerja"
})

fig_user = px.bar(
    user_pct,
    x="jenis_hari",
    y="persentase",
    color="segmen_pengguna",
    barmode="stack",
    text=user_pct["persentase"].map(
        lambda x: f"{x:.1f}%"
    ),
    color_discrete_map={
        "casual": ORANGE,
        "registered": BLUE
    },
    category_orders={
        "jenis_hari": [
            "Hari Kerja",
            "Hari Non-Kerja"
        ],
        "segmen_pengguna": [
            "casual",
            "registered"
        ]
    }
)

fig_user.update_layout(
    xaxis_title="Jenis Hari",
    yaxis_title="Kontribusi terhadap total penyewaan (%)",
    yaxis_range=[0, 100],
    legend_title="Segmen Pengguna",
    margin=dict(l=10, r=10, t=25, b=10)
)

fig_user.update_traces(
    textposition="inside"
)

st.plotly_chart(
    fig_user,
    use_container_width=True
)


# Rata-rata jumlah penyewaan per segmen
user_mean = (
    filtered_df.groupby("day_type")[
        ["casual", "registered"]
    ]
    .mean()
    .reindex(DAY_ORDER)
    .dropna(how="all")
    .reset_index()
    .melt(
        id_vars="day_type",
        var_name="segmen_pengguna",
        value_name="rata_rata"
    )
)

user_mean["jenis_hari"] = user_mean["day_type"].map({
    "Working Day": "Hari Kerja",
    "Weekend/Holiday": "Hari Non-Kerja"
})

fig_user_mean = px.bar(
    user_mean,
    x="jenis_hari",
    y="rata_rata",
    color="segmen_pengguna",
    barmode="group",
    text_auto=".0f",
    color_discrete_map={
        "casual": ORANGE,
        "registered": BLUE
    }
)

fig_user_mean.update_layout(
    title="Rata-Rata Penyewaan per Segmen dan Jenis Hari",
    xaxis_title="Jenis Hari",
    yaxis_title="Rata-rata penyewaan per hari",
    legend_title="Segmen Pengguna",
    margin=dict(l=10, r=10, t=50, b=10)
)

st.plotly_chart(
    fig_user_mean,
    use_container_width=True
)

st.markdown("---")


# =========================================================
# GRAFIK 3: TREN BULANAN
# =========================================================
st.subheader(
    "3. Tren Rata-Rata Penyewaan Berdasarkan Bulan"
)

monthly = (
    filtered_df.groupby(
        "mnth",
        as_index=False
    )
    .agg(
        rata_rata_penyewaan=("cnt", "mean")
    )
)

monthly["nama_bulan"] = monthly["mnth"].map(
    MONTH_NAMES
)

monthly = monthly.sort_values("mnth")

fig_month = px.line(
    monthly,
    x="nama_bulan",
    y="rata_rata_penyewaan",
    markers=True,
    text=monthly["rata_rata_penyewaan"].map(
        lambda x: f"{x:,.0f}"
    ),
    color_discrete_sequence=[GREEN]
)

fig_month.update_traces(
    line=dict(width=3),
    marker=dict(size=9),
    textposition="top center"
)

fig_month.update_layout(
    xaxis_title="Bulan",
    yaxis_title="Rata-rata penyewaan per hari",
    margin=dict(l=10, r=10, t=25, b=10)
)

st.plotly_chart(
    fig_month,
    use_container_width=True
)

st.markdown("---")


# =========================================================
# GRAFIK 4: DISTRIBUSI PER MUSIM
# =========================================================
st.subheader(
    "4. Distribusi Penyewaan Berdasarkan Musim"
)

fig_box = px.box(
    filtered_df,
    x="season_label",
    y="cnt",
    color="season_label",
    category_orders={
        "season_label": SEASON_ORDER
    },
    color_discrete_map={
        "Spring": LIGHT_BLUE,
        "Summer": BLUE,
        "Fall": ORANGE,
        "Winter": "#8D99AE"
    },
    points="outliers"
)

fig_box.update_layout(
    showlegend=False,
    xaxis_title="Musim",
    yaxis_title="Jumlah penyewaan per hari",
    margin=dict(l=10, r=10, t=25, b=10)
)

st.plotly_chart(
    fig_box,
    use_container_width=True
)

st.markdown("---")


# =========================================================
# RINGKASAN DATA
# =========================================================
st.subheader("5. Ringkasan Data")

col_a, col_b = st.columns(2)

with col_a:

    st.markdown(
        "**Ringkasan berdasarkan musim**"
    )

    st.dataframe(
        season_analysis.rename(columns={
            "season_label": "Musim",
            "rata_rata_penyewaan": "Rata-rata penyewaan",
            "total_penyewaan": "Total penyewaan",
            "jumlah_hari": "Jumlah hari"
        }).round(2),
        use_container_width=True,
        hide_index=True
    )

with col_b:

    st.markdown(
        "**Ringkasan berdasarkan jenis hari**"
    )

    day_summary = (
        filtered_df.groupby("day_type")
        .agg(
            jumlah_hari=("cnt", "count"),
            rata_rata_penyewaan=("cnt", "mean"),
            total_casual=("casual", "sum"),
            total_registered=("registered", "sum")
        )
        .reset_index()
        .rename(columns={
            "day_type": "Jenis hari",
            "jumlah_hari": "Jumlah hari",
            "rata_rata_penyewaan": "Rata-rata penyewaan",
            "total_casual": "Total casual",
            "total_registered": "Total registered"
        })
    )

    st.dataframe(
        day_summary.round(2),
        use_container_width=True,
        hide_index=True
    )


# Menampilkan data hasil filter
with st.expander("Lihat data hasil filter"):

    st.dataframe(
        filtered_df.sort_values("dteday"),
        use_container_width=True,
        hide_index=True
    )


# =========================================================
# DOWNLOAD DATA
# =========================================================
csv_data = filtered_df.to_csv(
    index=False
).encode("utf-8")

st.download_button(
    label="⬇️ Unduh data hasil filter (CSV)",
    data=csv_data,
    file_name="bike_sharing_filtered.csv",
    mime="text/csv"
)

st.markdown("---")

st.caption(
    "Sumber data: Bike Sharing Dataset (day.csv). "
    "Dashboard dibuat menggunakan Streamlit, Pandas, dan Plotly."
)
