
# 🚲 Bike Sharing Data Analysis

## 1. Deskripsi Proyek

Proyek ini bertujuan untuk menganalisis pola penyewaan sepeda menggunakan Bike Sharing Dataset periode 2011–2012. Analisis dilakukan untuk mengetahui pengaruh musim terhadap jumlah penyewaan serta membandingkan karakteristik pengguna casual dan registered berdasarkan jenis hari.

Hasil analisis digunakan untuk menghasilkan insight dan rekomendasi yang dapat mendukung strategi pengelolaan layanan penyewaan sepeda.

## 2. Tujuan Analisis

Analisis ini berfokus pada dua pertanyaan bisnis:

1. Bagaimana perbedaan rata-rata penyewaan sepeda antara musim Spring, Summer, Fall, dan Winter selama periode 2011–2012?
2. Bagaimana perbandingan persentase penyewaan pengguna casual dan registered terhadap total penyewaan pada hari kerja dan hari non-kerja selama periode 2011–2012?

## 3. Dataset

Dataset yang digunakan adalah Bike Sharing Dataset yang diperoleh dari UCI Machine Learning Repository.

- Periode data: 2011–2012
- Jumlah observasi: 731 baris
- Jumlah kolom: 16
- File utama: day.csv

Link dataset:
https://drive.google.com/file/d/1RaBmV6Q6FYWU4HWZs80Suqd7KQC34diQ/view

## 4. Tools dan Teknologi

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Plotly
- Streamlit
- Google Colab

## 5. Tahapan Analisis

1. Menentukan pertanyaan bisnis menggunakan pendekatan SMART.
2. Mengumpulkan dan memahami dataset.
3. Melakukan data assessment.
4. Melakukan data cleaning.
5. Melakukan Exploratory Data Analysis (EDA).
6. Membuat visualisasi data.
7. Melakukan analisis lanjutan.
8. Menyusun kesimpulan dan rekomendasi bisnis.
9. Mengembangkan dashboard interaktif menggunakan Streamlit.

## 6. Hasil Analisis dan Insight

- Musim Fall memiliki rata-rata penyewaan sepeda tertinggi.
- Musim Spring memiliki rata-rata penyewaan sepeda terendah.
- Pengguna registered mendominasi penyewaan pada hari kerja.
- Proporsi pengguna casual lebih tinggi pada hari non-kerja dibandingkan hari kerja.

## 7. Rekomendasi Bisnis

- Mengoptimalkan ketersediaan sepeda pada musim dengan tingkat penyewaan tinggi.
- Mengembangkan promosi khusus untuk meningkatkan penyewaan dari pengguna casual pada hari non-kerja.
- Mempertahankan strategi layanan bagi pengguna registered pada hari kerja.

## 8. Dashboard

Dashboard interaktif dikembangkan menggunakan Streamlit untuk menampilkan KPI, tren penyewaan, perbandingan segmen pengguna, serta pola penyewaan berdasarkan musim.

Link dashboard:
[Masukkan URL dashboard setelah dipublikasikan]

## 9. Cara Menjalankan Proyek

Instal seluruh library yang dibutuhkan:

pip install -r requirements.txt

Jalankan dashboard:

streamlit run app.py

## 10. Struktur Folder

Bike_Sharing_Project/
- app.py
- README.md
- requirements.txt
- url.txt
- day.csv
- Bike_Sharing_Analysis.ipynb
